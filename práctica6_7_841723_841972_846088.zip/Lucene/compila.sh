javac -d ./bin -cp ./lib/lucene-core-7.5.0.jar:./lib/lucene-analyzers-common-7.5.0.jar:./lib/lucene-queryparser-7.5.0.jar:./bin/ ./src/sistemasinformacion/practica5/IndexadorYBuscador.java

