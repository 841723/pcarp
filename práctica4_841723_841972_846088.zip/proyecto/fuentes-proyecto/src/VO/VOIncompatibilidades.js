class VOIncompatibilidades {
    constructor(idProducto1, idProducto2) {
        this.idProducto1 = idProducto1;
        this.idProducto2 = idProducto2;
    }
}
module.exports=VOIncompatibilidades