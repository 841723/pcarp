class VOResena {
    constructor(id_resena, id_usuario, id_producto, contenido, estrellas) {
        this.id_resena = id_resena;
        this.id_usuario = id_usuario;
        this.id_producto = id_producto;
        this.contenido = contenido;
        this.estrellas = estrellas;
    }
}

module.exports = VOResena