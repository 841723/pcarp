class VOUsuario {
    constructor(id_usuario,nombre,apellidos,contrasena,mail,direccion) {
        this.id_usuario = id_usuario;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.contrasena = contrasena;
        this.direccion = direccion;
        this.mail = mail;
    }

    // get id_usuario() {
    //     return this.id_usuario;
    // }
    // get nombre() {
    //     return this.nombre;
    // }
    // get apellidos() {
    //     return this.apellidos;
    // }
    // get contrasena() {
    //     return this.contrasena;
    // }
    // get direccion() {
    //     return this.direccion;
    // }
    // get mail() {
    //     return this.mail;
    // }

    // set id_usuario(value) {
    //     return this.id_usuario=value;
    // }
    // set nombre(value) {
    //     return this.nombre=value;
    // }
    // set apellidos(value) {
    //     return this.apellidos=value;
    // }
    // set contrasena(value) {
    //     return this.contrasena=value;
    // }
    // set direccion(value) {
    //     return this.direccion=value;
    // }
    // set mail(value) {
    //     return this.mail=value;
    // }
}

module.exports = VOUsuario