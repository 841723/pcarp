class VOContenidoPedidos {
    constructor(id_pedido, id_producto, cantidad) {
        this.id_pedido = id_pedido;
        this.id_producto = id_producto;
        this.cantidad = cantidad;
    }
}

module.exports = VOContenidoPedidos